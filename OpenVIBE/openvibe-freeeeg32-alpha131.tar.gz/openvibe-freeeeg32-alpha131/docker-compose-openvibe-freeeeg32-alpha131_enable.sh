ln -s $PWD/docker-compose-openvibe-freeeeg32-alpha131.service /etc/systemd/system
systemctl enable docker-compose-openvibe-freeeeg32-alpha131

docker manifest push --purge neuroidss/openvibe-ubuntu-xfce-vnc:2.2.0-freeeeg32-alpha131
